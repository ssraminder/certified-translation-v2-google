// This file provides a basic type declaration for the '@getbrevo/brevo' module,
// which does not ship with its own TypeScript types. This prevents a compilation
// error (TS7016) during the build process.

declare module '@getbrevo/brevo';
